BOSSPO ANDROID - GITHUB RELEASE SOURCE
=====================================
Nama aplikasi : BossPo
Package ID    : com.bosspo.juraganpo
Version       : 1.1.19
Version Code  : 7
Compile SDK   : 36
Target SDK    : 36
Min SDK       : 26

ALUR PALING MUDAH
1. Ekstrak BossPo_Source_GitHub_FRESH.zip.
2. Isi folder github_source dimasukkan ke repo GitHub BossPo, menggantikan source lama.
3. Commit/push ke branch main atau master.
4. Tab Actions akan menjalankan workflow "Build BossPo AAB" secara otomatis.
5. Tunggu build hijau/selesai.
6. Buka build tersebut > Artifacts.
7. Unduh artifact "BossPo-PlayStore-Release-v1.1.19".
8. Di dalam artifact ada file BossPo-PlayStore-Release-v1.1.19.aab.
9. Upload AAB itu ke Pengujian tertutup (Alpha) di Google Play Console.

GITHUB SECRETS YANG DIPERLUKAN
- BOSSPO_KEYSTORE_BASE64
- BOSSPO_STORE_PASSWORD
- BOSSPO_KEY_ALIAS
- BOSSPO_KEY_PASSWORD

Jika repo lama BossPo sebelumnya sudah berhasil build AAB melalui GitHub Actions,
biasanya secrets tersebut sudah tersimpan dan tidak perlu dibuat ulang.

KEAMANAN
File bosspo-upload-key.jks dan keystore.properties sengaja TIDAK disertakan dalam ZIP ini.
Jangan pernah memasukkan keystore/password ke repo GitHub publik.
