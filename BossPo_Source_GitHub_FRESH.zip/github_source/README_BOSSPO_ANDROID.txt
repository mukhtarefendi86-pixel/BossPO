BOSSPO ANDROID RELEASE PROJECT
==============================
Nama aplikasi : BossPo
Package ID    : com.bosspo.juraganpo
Version       : 1.0.0 (versionCode 1)
Compile SDK   : 36
Target SDK    : 36
Min SDK       : 26
Build Tools   : 36.0.0
AGP           : 9.4.0
Gradle        : 9.6.0

FITUR NATIVE YANG SUDAH DISIAPKAN
- Tampilan BossPo berjalan lokal/offline di Android WebView.
- Kamera/Galeri melalui file chooser Android.
- Open PO + foto dapat dibagikan melalui Sharesheet Android/WhatsApp.
- Backup JSON, CSV, dan list belanja menggunakan dialog Simpan File Android.
- Tautan WA/web dibuka melalui aplikasi eksternal.
- Tidak meminta izin kamera/penyimpanan permanen; akses dilakukan melalui aplikasi sistem.

BUILD AAB DI ANDROID STUDIO
1. Buka folder project ini di Android Studio terbaru.
2. Tunggu Gradle Sync dan instal SDK Platform 36 + Build Tools 36.0.0 jika diminta.
3. Pastikan file bosspo-upload-key.jks dan keystore.properties ada di root project.
4. Menu Build > Generate Signed App Bundle / APK.
5. Pilih Android App Bundle > Next.
6. Jika Android Studio membaca konfigurasi signing otomatis, pilih release dan Build.
   Jika wizard meminta key store, pilih bosspo-upload-key.jks, alias bosspo-upload,
   dan lihat password di keystore.properties.
7. Hasil AAB biasanya ada di app/build/outputs/bundle/release/app-release.aab.

PENTING
- Simpan bosspo-upload-key.jks dan keystore.properties dengan aman. Jangan dibagikan.
- Privacy Policy publik (URL https) tetap perlu diisi di Play Console sebelum rilis produksi.

CLOUD BUILD VIA GITHUB ACTIONS
- Workflow sudah tersedia di .github/workflows/build-aab.yml.
- Keystore TIDAK boleh di-commit; .gitignore sudah melindunginya.
- Workflow membutuhkan 4 GitHub Secrets:
  BOSSPO_KEYSTORE_BASE64, BOSSPO_STORE_PASSWORD, BOSSPO_KEY_ALIAS, BOSSPO_KEY_PASSWORD.
- Setelah secrets terpasang, jalankan workflow "Build BossPo AAB" dan unduh artifact BossPo-1.0.0-AAB.
