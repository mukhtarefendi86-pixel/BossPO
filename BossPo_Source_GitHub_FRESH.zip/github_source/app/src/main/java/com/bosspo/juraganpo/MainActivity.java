package com.bosspo.juraganpo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1001;
    private static final int REQ_SAVE = 1002;

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri pendingCameraUri;
    private byte[] pendingSaveBytes;
    private String pendingSaveMime = "application/octet-stream";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        View.OnApplyWindowInsetsListener insetsListener = (v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        };
        root.setOnApplyWindowInsetsListener(insetsListener);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);

        webView.setBackgroundColor(Color.BLACK);
        webView.addJavascriptInterface(new BossPoBridge(), "BossPoAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternal(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternal(Uri.parse(url));
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                pendingCameraUri = null;

                String accept = "*/*";
                if (params != null && params.getAcceptTypes() != null) {
                    for (String type : params.getAcceptTypes()) {
                        if (type != null && !type.trim().isEmpty()) { accept = type; break; }
                    }
                }

                boolean imageRequest = accept.startsWith("image/");
                boolean directCapture = imageRequest && params != null && params.isCaptureEnabled();

                // Tombol Kamera dari HTML memakai capture=environment. Buka kamera langsung
                // supaya pengguna tidak dilempar ke pemilih file terlebih dahulu.
                if (directCapture) {
                    Intent camera = createCameraIntent();
                    if (camera != null) {
                        try {
                            startActivityForResult(camera, REQ_FILE);
                            return true;
                        } catch (Exception ignored) {
                            pendingCameraUri = null;
                        }
                    }
                }

                Intent content = new Intent(Intent.ACTION_GET_CONTENT);
                content.addCategory(Intent.CATEGORY_OPENABLE);
                content.setType(accept);

                Intent chooser = Intent.createChooser(content, imageRequest ? "Pilih foto" : "Pilih file");
                if (imageRequest) {
                    Intent camera = createCameraIntent();
                    if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                }
                try {
                    startActivityForResult(chooser, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    pendingCameraUri = null;
                    return false;
                }
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private boolean handleExternal(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme();
        if (scheme == null || scheme.equals("file") || scheme.equals("about") || scheme.equals("data") || scheme.equals("blob")) {
            return false;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Aplikasi untuk membuka tautan tidak ditemukan.", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private Intent createCameraIntent() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            File file = File.createTempFile("bosspo_camera_", ".jpg", getCacheDir());
            pendingCameraUri = Uri.parse("content://" + getPackageName() + ".files/" + file.getName());
            camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            camera.setClipData(ClipData.newRawUri("BossPo Camera", pendingCameraUri));
            return camera;
        } catch (Exception e) {
            pendingCameraUri = null;
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (fileCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                } else if (pendingCameraUri != null) {
                    result = new Uri[]{pendingCameraUri};
                }
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
            pendingCameraUri = null;
            return;
        }
        if (requestCode == REQ_SAVE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingSaveBytes);
                        out.flush();
                        Toast.makeText(this, "File berhasil disimpan.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "Gagal menyimpan file.", Toast.LENGTH_SHORT).show();
                }
            }
            pendingSaveBytes = null;
            pendingSaveMime = "application/octet-stream";
        }
    }

    private void launchSave(String filename, String mime, byte[] bytes) {
        pendingSaveBytes = bytes;
        pendingSaveMime = mime == null || mime.trim().isEmpty() ? "application/octet-stream" : mime;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(pendingSaveMime);
        intent.putExtra(Intent.EXTRA_TITLE, sanitizeFilename(filename));
        try {
            startActivityForResult(intent, REQ_SAVE);
        } catch (Exception e) {
            pendingSaveBytes = null;
            Toast.makeText(this, "Dialog simpan tidak tersedia.", Toast.LENGTH_SHORT).show();
        }
    }

    private String sanitizeFilename(String name) {
        if (name == null || name.trim().isEmpty()) return "bosspo-file";
        return name.replaceAll("[\\\\/:*?\"<>|]", "-");
    }

    private static byte[] decodeDataUrl(String dataUrl) {
        if (dataUrl == null) return null;
        int comma = dataUrl.indexOf(',');
        if (comma < 0) return null;
        try { return Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT); }
        catch (Exception e) { return null; }
    }

    private static String mimeFromDataUrl(String dataUrl, String fallback) {
        if (dataUrl != null && dataUrl.startsWith("data:")) {
            int semi = dataUrl.indexOf(';');
            int comma = dataUrl.indexOf(',');
            int end = semi > 5 ? semi : comma;
            if (end > 5) return dataUrl.substring(5, end);
        }
        return fallback;
    }

    public class BossPoBridge {
        @JavascriptInterface
        public void saveDataUrl(String filename, String dataUrl, String mimeHint) {
            byte[] bytes = decodeDataUrl(dataUrl);
            if (bytes == null) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Data file tidak valid.", Toast.LENGTH_SHORT).show());
                return;
            }
            String mime = mimeFromDataUrl(dataUrl, mimeHint);
            runOnUiThread(() -> launchSave(filename, mime, bytes));
        }

        @JavascriptInterface
        public void share(String title, String text, String imageDataUrl) {
            runOnUiThread(() -> {
                try {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.putExtra(Intent.EXTRA_SUBJECT, title == null ? "BossPo" : title);
                    share.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    byte[] image = decodeDataUrl(imageDataUrl);
                    if (image != null && image.length > 0) {
                        String mime = mimeFromDataUrl(imageDataUrl, "image/jpeg");
                        String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
                        if (ext == null) ext = "jpg";
                        File file = File.createTempFile("bosspo_share_", "." + ext.toLowerCase(Locale.ROOT), getCacheDir());
                        try (FileOutputStream out = new FileOutputStream(file)) { out.write(image); }
                        Uri uri = Uri.parse("content://" + getPackageName() + ".files/" + file.getName());
                        share.setType(mime);
                        share.putExtra(Intent.EXTRA_STREAM, uri);
                        share.setClipData(ClipData.newRawUri("BossPo", uri));
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else {
                        share.setType("text/plain");
                    }
                    startActivity(Intent.createChooser(share, "Bagikan Open PO"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal membuka menu berbagi.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message == null ? "" : message, Toast.LENGTH_SHORT).show());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("BossPoAndroid");
            webView.destroy();
        }
        super.onDestroy();
    }
}
