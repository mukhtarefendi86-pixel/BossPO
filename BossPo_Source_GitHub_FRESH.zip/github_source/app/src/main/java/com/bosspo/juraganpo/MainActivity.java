package com.bosspo.juraganpo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1001;
    private static final int REQ_SAVE = 1002;

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private Uri pendingCameraUri;
    private byte[] pendingSaveBytes;
    private String pendingSaveMime = "application/octet-stream";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);

        View.OnApplyWindowInsetsListener insetsListener = (v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                        insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            }
            return insets;
        };
        root.setOnApplyWindowInsetsListener(insetsListener);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setTextZoom(90); // BossPo: keep UI compact and consistent on phones
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);

        webView.setBackgroundColor(Color.BLACK);
        webView.addJavascriptInterface(new BossPoBridge(), "BossPoAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternal(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternal(Uri.parse(url));
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                pendingCameraUri = null;

                String accept = "*/*";
                if (params != null && params.getAcceptTypes() != null) {
                    for (String type : params.getAcceptTypes()) {
                        if (type != null && !type.trim().isEmpty()) { accept = type; break; }
                    }
                }

                boolean imageRequest = accept.startsWith("image/");
                boolean directCapture = imageRequest && params != null && params.isCaptureEnabled();

                // Tombol Kamera dari HTML memakai capture=environment. Buka kamera langsung
                // supaya pengguna tidak dilempar ke pemilih file terlebih dahulu.
                if (directCapture) {
                    Intent camera = createCameraIntent();
                    if (camera != null) {
                        try {
                            startActivityForResult(camera, REQ_FILE);
                            return true;
                        } catch (Exception ignored) {
                            pendingCameraUri = null;
                        }
                    }
                }

                Intent content = new Intent(Intent.ACTION_GET_CONTENT);
                content.addCategory(Intent.CATEGORY_OPENABLE);
                content.setType(accept);

                Intent chooser = Intent.createChooser(content, imageRequest ? "Pilih foto" : "Pilih file");
                if (imageRequest) {
                    Intent camera = createCameraIntent();
                    if (camera != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                }
                try {
                    startActivityForResult(chooser, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    pendingCameraUri = null;
                    return false;
                }
            }
        });

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private boolean handleExternal(Uri uri) {
        if (uri == null) return false;
        String scheme = uri.getScheme();
        if (scheme == null || scheme.equals("file") || scheme.equals("about") || scheme.equals("data") || scheme.equals("blob")) {
            return false;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Aplikasi untuk membuka tautan tidak ditemukan.", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private Intent createCameraIntent() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            File file = File.createTempFile("bosspo_camera_", ".jpg", getCacheDir());
            pendingCameraUri = Uri.parse("content://" + getPackageName() + ".files/" + file.getName());
            camera.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            camera.setClipData(ClipData.newRawUri("BossPo Camera", pendingCameraUri));
            return camera;
        } catch (Exception e) {
            pendingCameraUri = null;
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE) {
            if (fileCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                } else if (pendingCameraUri != null) {
                    result = new Uri[]{pendingCameraUri};
                }
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
            pendingCameraUri = null;
            return;
        }
        if (requestCode == REQ_SAVE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) {
                        out.write(pendingSaveBytes);
                        out.flush();
                        Toast.makeText(this, "File berhasil disimpan.", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(this, "Gagal menyimpan file.", Toast.LENGTH_SHORT).show();
                }
            }
            pendingSaveBytes = null;
            pendingSaveMime = "application/octet-stream";
        }
    }

    private void launchSave(String filename, String mime, byte[] bytes) {
        pendingSaveBytes = bytes;
        pendingSaveMime = mime == null || mime.trim().isEmpty() ? "application/octet-stream" : mime;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(pendingSaveMime);
        intent.putExtra(Intent.EXTRA_TITLE, sanitizeFilename(filename));
        try {
            startActivityForResult(intent, REQ_SAVE);
        } catch (Exception e) {
            pendingSaveBytes = null;
            Toast.makeText(this, "Dialog simpan tidak tersedia.", Toast.LENGTH_SHORT).show();
        }
    }

    private String sanitizeFilename(String name) {
        if (name == null || name.trim().isEmpty()) return "bosspo-file";
        return name.replaceAll("[\\\\/:*?\"<>|]", "-");
    }

    private static byte[] decodeDataUrl(String dataUrl) {
        if (dataUrl == null) return null;
        int comma = dataUrl.indexOf(',');
        if (comma < 0) return null;
        try { return Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT); }
        catch (Exception e) { return null; }
    }

    private static String mimeFromDataUrl(String dataUrl, String fallback) {
        if (dataUrl != null && dataUrl.startsWith("data:")) {
            int semi = dataUrl.indexOf(';');
            int comma = dataUrl.indexOf(',');
            int end = semi > 5 ? semi : comma;
            if (end > 5) return dataUrl.substring(5, end);
        }
        return fallback;
    }

    private static String xmlEscape(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&apos;");
    }

    private static String excelColumn(int index) {
        StringBuilder out = new StringBuilder();
        int n = index + 1;
        while (n > 0) {
            int rem = (n - 1) % 26;
            out.insert(0, (char) ('A' + rem));
            n = (n - 1) / 26;
        }
        return out.toString();
    }

    private static void zipText(ZipOutputStream zip, String path, String text) throws Exception {
        ZipEntry entry = new ZipEntry(path);
        zip.putNextEntry(entry);
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static byte[] buildXlsx(String workbookJson) throws Exception {
        JSONObject root = new JSONObject(workbookJson == null ? "{}" : workbookJson);
        JSONArray sheets = root.optJSONArray("sheets");
        if (sheets == null || sheets.length() == 0) throw new IllegalArgumentException("No sheets");

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
            StringBuilder types = new StringBuilder();
            types.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                    .append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
                    .append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
                    .append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
                    .append("<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>")
                    .append("<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
            for (int i = 0; i < sheets.length(); i++) {
                types.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1)
                        .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            }
            types.append("</Types>");
            zipText(zip, "[Content_Types].xml", types.toString());

            zipText(zip, "_rels/.rels",
                    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                    "</Relationships>");

            StringBuilder workbook = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                    .append("<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
            StringBuilder rels = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                    .append("<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");

            for (int i = 0; i < sheets.length(); i++) {
                JSONObject sheet = sheets.getJSONObject(i);
                String name = sheet.optString("name", "Sheet" + (i + 1)).replaceAll("[\\\\/*?:\\[\\]]", "-");
                if (name.length() > 31) name = name.substring(0, 31);
                workbook.append("<sheet name=\"").append(xmlEscape(name)).append("\" sheetId=\"")
                        .append(i + 1).append("\" r:id=\"rId").append(i + 1).append("\"/>");
                rels.append("<Relationship Id=\"rId").append(i + 1)
                        .append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
                        .append(i + 1).append(".xml\"/>");

                JSONArray rows = sheet.optJSONArray("rows");
                StringBuilder ws = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
                        .append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
                if (rows != null) {
                    for (int r = 0; r < rows.length(); r++) {
                        JSONArray row = rows.optJSONArray(r);
                        if (row == null) continue;
                        ws.append("<row r=\"").append(r + 1).append("\">");
                        for (int c = 0; c < row.length(); c++) {
                            Object value = row.opt(c);
                            String ref = excelColumn(c) + (r + 1);
                            int style = r == 0 ? 1 : 0;
                            if (value instanceof Number) {
                                ws.append("<c r=\"").append(ref).append("\" s=\"").append(style).append("\"><v>")
                                        .append(value.toString()).append("</v></c>");
                            } else {
                                String text = value == null || value == JSONObject.NULL ? "" : String.valueOf(value);
                                ws.append("<c r=\"").append(ref).append("\" t=\"inlineStr\" s=\"").append(style)
                                        .append("\"><is><t xml:space=\"preserve\">").append(xmlEscape(text)).append("</t></is></c>");
                            }
                        }
                        ws.append("</row>");
                    }
                }
                ws.append("</sheetData></worksheet>");
                zipText(zip, "xl/worksheets/sheet" + (i + 1) + ".xml", ws.toString());
            }
            workbook.append("</sheets></workbook>");
            rels.append("<Relationship Id=\"rIdStyles\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            zipText(zip, "xl/workbook.xml", workbook.toString());
            zipText(zip, "xl/_rels/workbook.xml.rels", rels.toString());
            zipText(zip, "xl/styles.xml",
                    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                    "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                    "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><color rgb=\"FFD4AF37\"/><name val=\"Calibri\"/></font></fonts>" +
                    "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                    "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                    "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                    "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs>" +
                    "</styleSheet>");
        }
        return bytes.toByteArray();
    }

    public class BossPoBridge {
        @JavascriptInterface
        public void saveDataUrl(String filename, String dataUrl, String mimeHint) {
            byte[] bytes = decodeDataUrl(dataUrl);
            if (bytes == null) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Data file tidak valid.", Toast.LENGTH_SHORT).show());
                return;
            }
            String mime = mimeFromDataUrl(dataUrl, mimeHint);
            runOnUiThread(() -> launchSave(filename, mime, bytes));
        }

        @JavascriptInterface
        public void saveXlsx(String filename, String workbookJson) {
            try {
                byte[] bytes = buildXlsx(workbookJson);
                String safeName = filename == null || filename.trim().isEmpty() ? "BossPo-Laporan.xlsx" : filename;
                if (!safeName.toLowerCase(Locale.ROOT).endsWith(".xlsx")) safeName += ".xlsx";
                final String outName = safeName;
                runOnUiThread(() -> launchSave(outName,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", bytes));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Gagal membuat file Excel.", Toast.LENGTH_SHORT).show());
            }
        }

        @JavascriptInterface
        public void share(String title, String text, String imageDataUrl) {
            runOnUiThread(() -> {
                try {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.putExtra(Intent.EXTRA_SUBJECT, title == null ? "BossPo" : title);
                    share.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    byte[] image = decodeDataUrl(imageDataUrl);
                    if (image != null && image.length > 0) {
                        String mime = mimeFromDataUrl(imageDataUrl, "image/jpeg");
                        String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
                        if (ext == null) ext = "jpg";
                        File file = File.createTempFile("bosspo_share_", "." + ext.toLowerCase(Locale.ROOT), getCacheDir());
                        try (FileOutputStream out = new FileOutputStream(file)) { out.write(image); }
                        Uri uri = Uri.parse("content://" + getPackageName() + ".files/" + file.getName());
                        share.setType(mime);
                        share.putExtra(Intent.EXTRA_STREAM, uri);
                        share.setClipData(ClipData.newRawUri("BossPo", uri));
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else {
                        share.setType("text/plain");
                    }
                    startActivity(Intent.createChooser(share, "Bagikan Open PO"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal membuka menu berbagi.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void shareTo(String target, String title, String text, String imageDataUrl) {
            runOnUiThread(() -> {
                try {
                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.putExtra(Intent.EXTRA_SUBJECT, title == null ? "BossPo" : title);
                    share.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                    Uri imageUri = null;
                    byte[] image = decodeDataUrl(imageDataUrl);
                    if (image != null && image.length > 0) {
                        String mime = mimeFromDataUrl(imageDataUrl, "image/jpeg");
                        String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
                        if (ext == null) ext = "jpg";
                        File file = File.createTempFile("bosspo_share_", "." + ext.toLowerCase(Locale.ROOT), getCacheDir());
                        try (FileOutputStream out = new FileOutputStream(file)) { out.write(image); }
                        imageUri = Uri.parse("content://" + getPackageName() + ".files/" + file.getName());
                        share.setType(mime);
                        share.putExtra(Intent.EXTRA_STREAM, imageUri);
                        share.setClipData(ClipData.newRawUri("BossPo Promo", imageUri));
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else {
                        share.setType("text/plain");
                    }

                    String t = target == null ? "" : target.toLowerCase(Locale.ROOT);
                    String packageName = null;
                    if ("wa".equals(t) || "whatsapp".equals(t)) packageName = "com.whatsapp";
                    else if ("facebook".equals(t) || "fb".equals(t)) packageName = "com.facebook.katana";
                    else if ("instagram".equals(t) || "ig".equals(t)) packageName = "com.instagram.android";
                    else if ("tiktok".equals(t)) packageName = "com.zhiliaoapp.musically";

                    if (packageName != null) {
                        share.setPackage(packageName);
                        if (imageUri != null) {
                            grantUriPermission(packageName, imageUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        }
                    }
                    try {
                        startActivity(share);
                    } catch (ActivityNotFoundException notFound) {
                        if ("tiktok".equals(t)) {
                            try {
                                share.setPackage("com.ss.android.ugc.trill");
                                startActivity(share);
                                return;
                            } catch (ActivityNotFoundException ignored) { }
                        }
                        share.setPackage(null);
                        startActivity(Intent.createChooser(share, "Bagikan Open PO"));
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal membuka menu berbagi.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void toast(String message) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, message == null ? "" : message, Toast.LENGTH_SHORT).show());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("BossPoAndroid");
            webView.destroy();
        }
        super.onDestroy();
    }
}
